
import java.util.*;
import java.util.ArrayList;

public class Main {
	static List<ArrayList<ArrayList<Object>>> externalDatabase = new ArrayList<ArrayList<ArrayList<Object>>>();
	static ArrayList<String> names = new ArrayList<String>();
	static ArrayList<Integer> rows = new ArrayList<Integer>();

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Please name the first DATABASE field");
		String l = input.next();
		names.add(l);
		externalDatabase.add(new ArrayList<ArrayList<Object>>(Data.database()));
		rows.add(Values.rows);
		int flag = 0;
		while (flag == 0) {
			System.out.println("Do you want to add another DATABASE field ? y/n");
			String t = input.next();
			if (t.equals("y")) {
				Data.database.clear();
				Values.rows = 1;
				System.out.println("Please name the DATABASE field you want to add");
				l = input.next();
				names.add(l);
				externalDatabase.add(new ArrayList<ArrayList<Object>>(Data.database()));
				rows.add(Values.rows);
			} else if (t.equals("n")) {
				flag = 1;
				for (int y = 0; y < names.size(); y++) {
					printData(y);
				}
			}
		}
		input.close();
	}

	public static void printData(int y) {
		System.out.println("   " + names.get(y) + "");
		for (int z = 0; z < rows.get(y); z++) {
			System.out.println(externalDatabase.get(y).get(z));
		}

	}

}
