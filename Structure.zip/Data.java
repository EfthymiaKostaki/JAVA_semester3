
import java.util.ArrayList;

public class Data {
	static ArrayList<ArrayList<Object>> database = new ArrayList<ArrayList<Object>>();

	public static ArrayList<ArrayList<Object>> database() {
		// TODO Auto-generated method stub
		int counter = 0;
		int choice;
		AddField.addField(counter, database);
		counter++;
		do {
			choice = Menu.printMenu(database);
			if (choice == 1) {
				AddField.addField(counter, database);
			} else if (choice == 2) {
				Values.giveValues(database);
			} else if (choice == 3) {

			}
		} while (choice != 4);
		return database;
	}
}
