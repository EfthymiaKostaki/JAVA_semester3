package Det;

import java.util.*;
import java.util.ArrayList;

public class Data {
	static ArrayList<ArrayList<Object>> database=new ArrayList<ArrayList<Object>>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int counter=0, column, row;
		int choice = Menu.printMenu(counter,database);
		counter = counter ++;
		while (choice != 4) {
			if (choice == 1) {
				
			}
		}
	}
	
	
	
	
	
	
	
	public Data(ArrayList<ArrayList<Object>> database) {
		super();
		this.database = database;
	}
	
	

}
