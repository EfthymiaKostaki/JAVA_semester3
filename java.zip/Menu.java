package Det;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {

	public static int printMenu(int counter, ArrayList<ArrayList<Object>> database) {
		int choice=4;
		if (counter > 1) {
			do {
				System.out.println("Make a choice");
				System.out.println("1.Add a field");
				System.out.println("2. ...");
				System.out.println("3. ...");
				System.out.println("4. Exit");
				Scanner input = new Scanner(System.in);
				choice=input.nextInt();
			} while (choice <= 0 || choice > 4); 
		} else {
			int rows=0;
			int z=0;	
			do {
				System.out.println("Please name the field you want to add");
				Scanner input = new Scanner(System.in);
				Object x=input.next();
				database.add(new ArrayList<Object>());
				database.get(0).add(x);
			
				int flag=0;
				while (flag == 0) {
					System.out.println("Do you want to add another field ? y/n");
					String t= input.next();
					if (t.equals("y")) {
						System.out.println("Please name the field you want to add");
						Object l=input.next();
						database.add(new ArrayList<Object>());
						database.get(0).add(l);
					} else if (t.equals("n")) {
						flag=1;
					    z=1;
						System.out.println(database);
					}
				}
				} while (z != 1);
			}
			
		  
		return choice; 
	}
}
